import math
from scipy.special import digamma

def calculate_time(a, b, s, B, R, N):
    # 計算ロジック本体
    K = B * R
    n = int((b - a) // s)
    C = 60 * K
    
    # 計算実行 (厳密解・近似解)
    step_times = [C / (a + s * k) for k in range(n + 1)]
    exact = math.fsum(step_times) * N
    
    # 簡易近似
    S = a + (a + n * s)
    P = a * (a + n * s)
    term = (4 * n * S) / (S**2 + 4 * P) + S / (2 * P)
    approx = C * term * N
    
    return exact, approx
