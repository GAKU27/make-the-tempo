import argparse
import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from core import calculate_time

def main():
    p = argparse.ArgumentParser()
    p.add_argument("-a", type=float, required=True)
    p.add_argument("-b", type=float, required=True)
    p.add_argument("-s", type=float, default=2)
    p.add_argument("-B", type=int, default=4)
    p.add_argument("-R", type=int, default=4)
    p.add_argument("-N", type=int, default=1)
    args = p.parse_args()

    exact, approx = calculate_time(args.a, args.b, args.s, args.B, args.R, args.N)
    print(f"厳密解: {exact:.2f}秒")
    print(f"近似解: {approx:.2f}秒")

if __name__ == "__main__":
    main()
